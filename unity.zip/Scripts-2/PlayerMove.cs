using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//��ǥ1 : �÷��̾ �����δ� (��ġ = ��ġ0 + �ӵ� x �ð�) 

public class PlayerMove : MonoBehaviour
{
  public   float speed = 5;
    // Start is called before the first frame update

    // Update is called once per frame
    void Update()
    {
        float h = Input.GetAxisRaw("Horizontal");
        float v = Input.GetAxisRaw("Vertical"); 
        Vector3 dir = Vector3.right * h + Vector3.up * v;
        transform.position += dir * speed * Time.deltaTime;
        
    }
}
